# BarcodeReaderSample
A barcode scanner example using Google Play services.

[This tutorial](https://www.varvet.com/blog/android-qr-code-reader-made-easy/) should be of interest :). 
