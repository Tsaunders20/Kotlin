package com.varvet.barcodereadersample

import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import java.io.FileReader
import android.app.Activity
import android.app.PendingIntent.getActivity
import android.content.Intent
import android.content.Intent.getIntent
import com.google.android.gms.common.api.CommonStatusCodes
import androidx.core.content.ContextCompat.startActivity




class MainAdapter: RecyclerView.Adapter<CustomViewHolder>(){

    val read = FileReader("/data/data/com.varvet.barcodereadersample/files/config.txt")
    var filetxt = read.readText()
    var myDataset = filetxt.split("],[")
    var output = ""



    override fun getItemCount(): Int {
       //  return .size;
        return myDataset.size
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): CustomViewHolder {
        val layoutInflater = LayoutInflater.from(parent?.context)
        val cellForRow = layoutInflater.inflate(R.layout.eachload,parent,false)
        var theid = cellForRow.findViewById<TextView>(R.id.maintextview);
        return CustomViewHolder(cellForRow,theid)
    }

    override fun onBindViewHolder(holder: CustomViewHolder, position: Int) {
        var thearray = myDataset[position]
        var thesplit = thearray.split(",")
       holder?.view?.findViewById<Button>(R.id.maintextview)?.setOnClickListener{
            var output = holder.view.findViewById<Button>(R.id.maintextview)?.text
           val intent = Intent(holder.view.context, MainActivity::class.java)


           intent.putExtra("theload",thearray)
           //intent.putExtra("theload",output)

           holder.view.context.startActivity(intent)
        }
        holder?.view?.findViewById<Button>(R.id.maintextview)?.text = thesplit[1]
    }
}
class CustomViewHolder(val view: View,val theid: TextView): RecyclerView.ViewHolder(view){

   /* init {
        view.setOnClickListener {

            System.out.println("In")
            val intent = Intent(view.context, MainActivity::class.java)
            intent.putExtra("theload","blarg")

            view.context.startActivity(intent)
        }
    }*/
}