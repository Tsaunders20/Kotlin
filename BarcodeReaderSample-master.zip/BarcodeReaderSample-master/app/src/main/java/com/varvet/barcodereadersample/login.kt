package com.varvet.barcodereadersample



import android.content.Intent
import android.os.Bundle
import android.widget.Button
import com.github.kittinunf.fuel.httpPost
import com.github.kittinunf.result.Result

import kotlinx.android.synthetic.main.login.*
import androidx.appcompat.app.AppCompatActivity
import com.github.kittinunf.fuel.Fuel



import org.json.JSONObject
import android.widget.EditText
import android.R.attr.name
import android.R.id
import android.content.Context
import com.github.kittinunf.fuel.core.Headers
import android.content.SharedPreferences




class login : AppCompatActivity() {


    private var PRIVATE_MODE = 0
    private val PREF_NAME = "login"
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.login)


        val sharedPref: SharedPreferences = getSharedPreferences(PREF_NAME, PRIVATE_MODE)


        var editor = sharedPref.edit()



        println("before")
        postdata()


        findViewById<Button>(R.id.main_login_button).setOnClickListener {
            login()
           /* try {
               login()

            } catch (e:Exception){
                println("test")
            }*/
        }



















    }
    fun postdata() {


        val bodyJson = """
              { "user" : "tom@russellipm.com",
              }
            """

        println("in")
        "http://e-trap.net/mobile-login.php".httpPost().body(bodyJson)
                .response{
            request, response, result ->
            when (result) {
                is Result.Failure -> {
                    val ex = result.getException()
                    println(ex)
                    println("Fail")
                    val (payload, error) = result
                    println(payload)
                }
                is Result.Success -> {
                    val data = result.get()
                    println(data)
                    println("Success")
                }
            }
            //response handling
        }




    }
    fun login(){





        val sharedPref: SharedPreferences = getSharedPreferences(PREF_NAME, PRIVATE_MODE)


        var editor = sharedPref.edit()




        val userbtn = findViewById<EditText>(R.id.login_user)
        val username = ""+userbtn.text.toString()

        val passbtn = findViewById<EditText>(R.id.login_password)
        val password = ""+passbtn.text.toString()



        val jsoncode = JSONObject()
        jsoncode.put("username", username)
        jsoncode.put("password", password)


        "https://e-trap.net/submitloginmobile.php".httpPost()
                .header("Content-Type", "application/json")
                .body(jsoncode.toString())
                .response{
                    request, response, result ->
                    when (result) {
                        is Result.Failure -> {
                            val ex = result.getException()
                            println(ex)
                            println("Fail")
                            val (payload, error) = result
                            println(payload)
                        }
                        is Result.Success -> {
                            val data = result.get()
                            val inputjson = "{"+response.toString()+"}"
                            if(response.toString().indexOf("Logged in") != -1){
                                // User Login came back successful
                                println("ayyy")
                                editor.clear()
                                editor.putString("status","logged in")
                                editor.putString("user",username)
                                editor.commit()
                                val intent = Intent(applicationContext, MainActivity::class.java)
                                startActivity(intent)
                            }
                            else{
                                //Invalid Login
                                editor.clear()

                            }

                        }
                    }
                    //response handling
                }





    }








}

