package com.varvet.barcodereadersample

import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.util.Log
import android.view.View
import android.view.View.*
import android.view.WindowManager
import android.widget.Button
import android.widget.TextView
import com.google.android.gms.common.api.CommonStatusCodes
import com.google.android.gms.vision.barcode.Barcode
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.content.Context.MODE_PRIVATE
import android.R.string.cancel
import android.app.Dialog
import android.app.DialogFragment
import android.app.PendingIntent
import android.app.TaskStackBuilder
import android.content.DialogInterface
import android.content.SharedPreferences
import android.graphics.Color
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.core.app.NotificationCompat
import androidx.appcompat.app.AlertDialog
import android.widget.EditText
import android.widget.Toast
import com.github.kittinunf.fuel.httpPost
import com.github.kittinunf.result.Result
import com.varvet.barcodereadersample.barcode.barcodecapture
import org.json.JSONObject
import java.io.*


class MainActivity : AppCompatActivity() {

    private lateinit var mResultTextView: TextView
    private val TAG = MainActivity::class.java.simpleName

    private var PRIVATE_MODE = 0
    private val PREF_NAME = "login"


    @Override
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        val sharedPref: SharedPreferences = getSharedPreferences(PREF_NAME, PRIVATE_MODE)
        

// Hide the status bar.
        window.decorView.systemUiVisibility = SYSTEM_UI_FLAG_FULLSCREEN
// Remember that you should never show the action bar if the
// status bar is hidden, so hide that too if necessary.
        actionBar?.hide()

        setContentView(R.layout.activity_main)




        var savebutton = findViewById<Button>(R.id.save_button)
        var loadbutton = findViewById<Button>(R.id.load_button)
        var managebutton = findViewById<Button>(R.id.manage_button)

        var test = findViewById<Button>(R.id.scan_barcode_button)
        var animation=AnimationUtils.loadAnimation(this,R.anim.pulse)

        test.startAnimation(animation)



        mResultTextView = findViewById(R.id.result_textview)


try {
    mResultTextView.text = sharedPref.getString("user", "Please Log in")
}
catch (e:Exception){

}


        try {
            val read = FileReader("/data/data/com.varvet.barcodereadersample/files/config.txt")



            loadbutton.visibility = VISIBLE
            managebutton.visibility = VISIBLE
            println(read.readText())


        } catch (e:Exception){
            println(e.message)
        }

        findViewById<Button>(R.id.scan_barcode_button).setOnClickListener {
            val intent = Intent(applicationContext, barcodecapture::class.java)
            startActivityForResult(intent, BARCODE_READER_REQUEST_CODE)
            savebutton.visibility = VISIBLE
        }
        findViewById<Button>(R.id.load_button).setOnClickListener {
            try {
                val read = FileReader("/data/data/com.varvet.barcodereadersample/files/config.txt")

                val intent = Intent(applicationContext, newload::class.java)
                startActivity(intent)


            } catch (e:Exception){

            }
        }
        findViewById<Button>(R.id.save_button).setOnClickListener { it ->

            var tv = findViewById<TextView>(R.id.result_textview)
            val a = tv.text.toString()
            var QRID = a.substring(17,a.indexOf("\n\n"+"Sending to database now."))

            var list: MutableList<String> = mutableListOf<String>()
            var foundold = 0;
            try {
                val read = FileReader("/data/data/com.varvet.barcodereadersample/files/config.txt")

                var loaded = read.readText()

                if(loaded.isNotEmpty()) {
                    var check = 0
                    var previous = 0;
                    var stripper = loaded;
                    while(check == 0) {
                        var newadd = stripper.substring(previous,stripper.indexOf("]")+1)
                        if(stripper.indexOf("]")+2 > stripper.length) {
                            stripper = stripper.substring(0,stripper.length)

                        }
                        else {
                            stripper = stripper.substring(stripper.indexOf("]") + 2, stripper.length)
                        }


                        list.add(newadd)
                        if(stripper.length == 0 || newadd.length == stripper.length){
                            check = 1
                            System.out.println("Out")
                        }
                    }
                    System.out.println(list)
                    list.forEach {
                        val theid = it.substring(1,it.indexOf(" "))
                        if(QRID == theid){
                            foundold = 1
                        }
                    }

                }
            val builder = AlertDialog.Builder(this@MainActivity)

            // Set the alert dialog title
                if(foundold == 0) {


                    builder.setTitle("Name your item.")

                    var editer = layoutInflater.inflate(R.layout.prompts, null)
                    // Set above view in alert dialog.
                    builder.setView(editer)

                    builder.setPositiveButton("Save Name") {

                        dialog, id ->

                        var new = editer.findViewById<EditText>(R.id.editTextDialogUserInput)
                        var newa = ""
                        newa = if (!new.text.toString().isEmpty()) {
                            new.text.toString()
                        } else {
                            "Yeah it was null."
                        }
                        var input = ""
                        if (loaded.isNotEmpty()) {
                            input = "$loaded,[$QRID , $newa]"
                        } else {
                            input = "[$QRID , $newa]"
                        }

                        writeToFile(input, applicationContext)
                        mResultTextView.text = "$newa Saved."







                        dialog.cancel()
                    }
                }
                else{
                    builder.setTitle("This Trap has already been saved.")

                    var editer = layoutInflater.inflate(R.layout.rename, null)
                    // Set above view in alert dialog.
                    builder.setView(editer)

                    builder.setPositiveButton("Rename") {

                        dialog, id ->

                        var new = editer.findViewById<EditText>(R.id.editTextDialogUserInput)
                        var newa = ""
                        newa = if (!new.text.toString().isEmpty()) {
                            new.text.toString()
                        } else {
                            "Yeah it was null."
                        }
                        var input = loaded
                        list.forEach {
                            val theid = it.substring(1,it.indexOf(" "))
                            if(it.indexOf("$QRID ,") >0){
                                var find = "[$theid , ";
                                var thename = loaded.substring(loaded.indexOf(find)+find.length,loaded.indexOf("]"))
                                input = loaded.replace("[$theid , $thename","[$theid , $newa")
                            }
                        }


                        writeToFile(input, applicationContext)
                        mResultTextView.text = "$newa Renamed."







                        dialog.cancel()
                    }
                }

            // Set a positive button and its click listener on alert dialog


            // Finally, make the alert dialog using builder
            val dialog: AlertDialog = builder.create()

            // Display the alert dialog on app interface
            dialog.show()

            } catch (e:Exception){

                val builder = AlertDialog.Builder(this@MainActivity)
                // Set the alert dialog title
                    builder.setTitle("Name your item.")
                    var editer = layoutInflater.inflate(R.layout.prompts, null)
                    // Set above view in alert dialog.
                    builder.setView(editer)
                    builder.setPositiveButton("Save Name") {

                        dialog, id ->

                        var new = editer.findViewById<EditText>(R.id.editTextDialogUserInput)
                        var newa = ""
                        newa = if (!new.text.toString().isEmpty()) {
                            new.text.toString()
                        } else {
                            "Yeah it was null."
                        }
                        var input = ""

                            input = "[$QRID , $newa]"

                        writeToFile(input, applicationContext)
                        System.out.println("Saved First")
                        mResultTextView.text = "$newa Saved."


                        dialog.cancel()
                    }
                val dialog: AlertDialog = builder.create()

                // Display the alert dialog on app interface
                dialog.show()
            }
            loadbutton.visibility = VISIBLE
        }
        findViewById<Button>(R.id.manage_button).setOnClickListener {
            try {
                val read = FileReader("/data/data/com.varvet.barcodereadersample/files/config.txt")
                val intent = Intent(applicationContext, manageconfig::class.java)
                startActivity(intent)

            } catch (e:Exception){
            }
        }
        findViewById<Button>(R.id.login_button).setOnClickListener {
            try {
                println("in")
                val intent = Intent(applicationContext, login::class.java)
                startActivity(intent)

            } catch (e:Exception){
                println("test")
           }
        }



        try{
            val theload = intent.getStringExtra("theload")
            var loadedid = theload.substring(0,theload.indexOf(" ,"))
            loadedid = loadedid.replace("[","")
            var loadedname = theload.substring(theload.indexOf(" ,")+3,theload.length)
            loadedname = loadedname.replace("]","")
            System.out.println("The ID was: $loadedid and the name was: $loadedname")
        }
        catch (e:Exception){
            println(e.message)
        }




    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        if (requestCode == BARCODE_READER_REQUEST_CODE) {
            if (resultCode == CommonStatusCodes.SUCCESS) {
                if (data != null) {
                    val barcode = data.getParcelableExtra<Barcode>(barcodecapture.BarcodeObject)
                    val p = barcode.cornerPoints
                    var input = "Your result was: " +barcode.displayValue +"\n\nSending to database now."


                    sendQR(barcode.displayValue)

                    mResultTextView.text = input
                } else {
                    mResultTextView.setText(R.string.no_barcode_captured)
                }
            } else
                Log.e(LOG_TAG, String.format(getString(R.string.barcode_error_format),
                        CommonStatusCodes.getStatusCodeString(resultCode)))
        } else
            super.onActivityResult(requestCode, resultCode, data)
    }
    fun sendQR(barcode: String){


        val sharedPref: SharedPreferences = getSharedPreferences(PREF_NAME, PRIVATE_MODE)


        val username = sharedPref.getString("user", "Not logged in")

        var output = "Blarg"



        println(username)
        println(barcode)



        val jsoncode = JSONObject()
        jsoncode.put("username", username)
        jsoncode.put("QR", barcode)





        "https://e-trap.net/submitscan.php".httpPost()
                .header("Content-Type", "application/json")
                .body(jsoncode.toString())
                .response{
                    request, response, result ->
                    when (result) {

                        is Result.Failure -> {
                            println("down")
                            //Failed to connect - internet probably down

                            val ex = result.getException()
                            val (payload, error) = result



                            mResultTextView.text = "Failed"
                        }
                        is Result.Success -> {
                            mResultTextView.text = "Scan successfully sent to database"
                        }
                    }

                    //response handling
                }
    }
    private fun writeToFile(data: String, context: Context) {
        try {
            val outputStreamWriter = OutputStreamWriter(context.openFileOutput("config.txt", Context.MODE_PRIVATE))
            outputStreamWriter.write(data)
            outputStreamWriter.close()
        } catch (e: IOException) {
            Log.e("Exception", "File write failed: " + e.toString())
        }

    }
    companion object {
        private val LOG_TAG = MainActivity::class.java.simpleName
        private val BARCODE_READER_REQUEST_CODE = 1
    }
}
