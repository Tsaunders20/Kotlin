package com.varvet.barcodereadersample;

public class AppConfig {
    // Server user login url
    var URL_LOGIN = "http://192.168.0.102/android_login_api/login.php"

    // Server user register url
    var URL_REGISTER = "http://192.168.0.102/android_login_api/register.php"
}