package com.varvet.barcodereadersample

import java.util.*
import android.accessibilityservice.GestureDescription
import android.content.Context
import android.content.Intent
import android.os.Build
import android.os.Bundle
import androidx.appcompat.app.AppCompatActivity
import android.util.Log
import android.view.View
import android.view.View.*
import android.view.WindowManager
import com.google.android.gms.common.api.CommonStatusCodes
import com.google.android.gms.vision.barcode.Barcode
import android.view.animation.Animation
import android.view.animation.AnimationUtils
import android.content.Context.MODE_PRIVATE
import android.R.string.cancel
import android.app.ActionBar
import android.app.Dialog
import android.app.DialogFragment
import android.content.DialogInterface
import android.graphics.Color
import androidx.constraintlayout.widget.ConstraintLayout
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.*
import com.varvet.barcodereadersample.R.attr.layoutManager
import java.io.*
import kotlin.collections.ArrayList


class newload : AppCompatActivity() {

    private lateinit var viewManager: RecyclerView.LayoutManager

    @Override
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.loadscreen)
        //viewManager = LinearLayoutManager(this)
        viewManager = LinearLayoutManager(this)
        val read = FileReader("/data/data/com.varvet.barcodereadersample/files/config.txt")
        var filetxt = read.readText()
        var myDataset = filetxt.split("],[")
         myDataset = ArrayList(myDataset)

        findViewById<Button>(R.id.noload).setOnClickListener{
            finish()
        }

        var recyclerView_main = findViewById<RecyclerView>(R.id.loads)
        recyclerView_main.layoutManager = LinearLayoutManager(this)
        recyclerView_main.adapter = MainAdapter()
        var test = MainAdapter().output
        System.out.println(test)

    }

    }
